var indexSectionsWithContent =
{
  0: "abcdfghilmnoprstw",
  1: "dfgips",
  2: "dips",
  3: "bcdfhlmoprstw",
  4: "dimps",
  5: "d",
  6: "firs",
  7: "a"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines",
  6: "groups",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Macros",
  6: "Modules",
  7: "Pages"
};

